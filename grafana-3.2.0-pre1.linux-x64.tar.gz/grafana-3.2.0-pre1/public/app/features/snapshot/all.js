/*! grafana - v3.2.0-pre1 - 2016-06-27
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./snapshot_ctrl"],function(a){return{setters:[function(a){}],execute:function(){}}});