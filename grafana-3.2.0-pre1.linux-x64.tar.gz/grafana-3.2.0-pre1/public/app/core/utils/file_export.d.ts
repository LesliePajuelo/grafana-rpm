/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare function exportSeriesListToCsv(seriesList: any): void;
export declare function exportSeriesListToCsvColumns(seriesList: any): void;
export declare function exportTableDataToCsv(table: any): void;
export declare function saveSaveBlob(payload: any, fname: any): void;
