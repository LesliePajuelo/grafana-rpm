/// <reference path="../../../../../public/app/headers/common.d.ts" />
import { QueryCtrl } from 'app/plugins/sdk';
export declare class CloudWatchQueryCtrl extends QueryCtrl {
    static templateUrl: string;
    aliasSyntax: string;
    /** @ngInject **/
    constructor($scope: any, $injector: any);
}
