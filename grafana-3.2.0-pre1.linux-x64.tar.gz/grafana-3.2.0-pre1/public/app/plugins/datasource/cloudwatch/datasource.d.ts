declare var CloudWatchDatasource: any;
export {CloudWatchDatasource};

